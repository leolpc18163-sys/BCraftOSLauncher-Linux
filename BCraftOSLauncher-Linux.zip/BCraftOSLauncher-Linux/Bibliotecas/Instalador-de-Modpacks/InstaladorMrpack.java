package BCraftOSproject1.BCraftOS1;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Instala um modpack do Modrinth (.mrpack) como um modpack do launcher.
 *
 * O resultado é uma pasta dentro de modpacks/ da versão escolhida:
 *   modpacks/NomeDoModpack/*.jar          os mods (o launcher copia para run/mods ao jogar)
 *   modpacks/NomeDoModpack/overrides/...  configs e outros arquivos do modpack (copiados para run/ sem
 *                                         sobrescrever o que você já mexeu)
 *
 * Só entram os arquivos que o cliente usa. Cada download é conferido pelo SHA-1, só vêm de hospedeiros
 * permitidos e nenhum caminho do pacote consegue escrever fora da pasta do modpack.
 */
public final class InstaladorMrpack {

	private static final long LIMITE_INDICE = 8L * 1024 * 1024;
	private static final long LIMITE_DESCOMPACTADO = 1_500L * 1024 * 1024;

	private InstaladorMrpack() {
	}

	/** Nome do loader no pacote -> nome usado no launcher/Modrinth. */
	private static String loaderDoPacote(Map<String, Object> dependencias) {
		if (dependencias.containsKey("neoforge")) {
			return "neoforge";
		}
		if (dependencias.containsKey("forge")) {
			return "forge";
		}
		if (dependencias.containsKey("fabric-loader")) {
			return "fabric";
		}
		if (dependencias.containsKey("quilt-loader")) {
			return "quilt";
		}
		return null;
	}

	/** Devolve o nome do modpack criado. Se algo falhar, a pasta incompleta é apagada. */
	public static String instalar(CatalogoModrinth.Versao versao, String slug, GerenciadorBiblioteca.Destino destino,
			GerenciadorDownloads.Progresso progresso) throws Exception {
		if (destino.servidor || destino.pastaVersao == null) {
			throw new IllegalStateException("Modpacks se instalam numa versão do cliente (aba Jogar).");
		}
		if (!versao.arquivo.nome.toLowerCase(Locale.ROOT).endsWith(".mrpack")) {
			throw new IllegalStateException("Esse modpack não vem no formato .mrpack e não dá para instalar aqui.");
		}

		// 1. O pacote vai para a biblioteca (fica guardado, dá para reinstalar sem internet).
		File pastaPacote = new File(new File(GerenciadorBiblioteca.pastaBiblioteca(), GerenciadorBiblioteca.PASTA_MODPACKS),
				GerenciadorBiblioteca.nomeSeguro(slug == null ? versao.projetoId : slug));
		File pacote = new File(pastaPacote, GerenciadorBiblioteca.nomeDeArquivoSeguro(versao.arquivo.nome));
		GerenciadorBiblioteca.baixarVerificado(versao.arquivo, pacote, progresso, 2, 20);

		File modpackDir = null;
		try (ZipFile zip = new ZipFile(pacote)) {
			// 2. Índice do pacote
			ZipEntry entradaIndice = zip.getEntry("modrinth.index.json");
			if (entradaIndice == null || entradaIndice.getSize() > LIMITE_INDICE) {
				throw new IOException("Esse .mrpack não tem um modrinth.index.json válido.");
			}
			String jsonIndice;
			try (InputStream in = zip.getInputStream(entradaIndice)) {
				jsonIndice = new String(in.readNBytes((int) LIMITE_INDICE), StandardCharsets.UTF_8);
			}
			Map<String, Object> indice = MiniJson.objeto(MiniJson.ler(jsonIndice));
			if (indice == null || !"minecraft".equals(MiniJson.texto(indice.get("game")))) {
				throw new IOException("O índice do modpack não é de Minecraft.");
			}
			conferirCompatibilidade(indice, destino);

			// 3. Pasta do modpack (nome novo, nunca sobrescreve um existente)
			String base = GerenciadorBiblioteca.nomeSeguro(MiniJson.texto(indice.get("name")));
			if (base.isEmpty()) {
				base = GerenciadorBiblioteca.nomeSeguro(slug);
			}
			if (base.isEmpty()) {
				base = "Modpack";
			}
			File pastaModpacks = GerenciadorModpacks.obterPastaModpacks(destino.pastaVersao);
			String nome = base;
			for (int n = 2; new File(pastaModpacks, nome).exists(); n++) {
				nome = base + "-" + n;
			}
			modpackDir = new File(pastaModpacks, nome);
			modpackDir.mkdirs();
			Path raizModpack = modpackDir.getCanonicalFile().toPath();

			// 4. Arquivos listados no índice (mods e afins)
			List<Object> arquivos = MiniJson.lista(indice.get("files"));
			int total = Math.max(1, arquivos.size());
			int feitos = 0;
			for (Object item : arquivos) {
				Map<String, Object> f = MiniJson.objeto(item);
				feitos++;
				if (f == null) {
					continue;
				}
				Map<String, Object> env = MiniJson.objeto(f.get("env"));
				if (env != null && "unsupported".equals(MiniJson.texto(env.get("client")))) {
					continue; // mod só de servidor
				}
				String caminho = MiniJson.texto(f.get("path"));
				Path alvo = caminhoSeguro(raizModpack, destinoDentroDoModpack(caminho));
				CatalogoModrinth.Arquivo a = new CatalogoModrinth.Arquivo();
				a.nome = alvo.getFileName().toString();
				List<Object> links = MiniJson.lista(f.get("downloads"));
				for (Object l : links) {
					String url = MiniJson.texto(l);
					if (url != null && CatalogoModrinth.enderecoPermitido(url)) {
						a.url = url;
						break;
					}
				}
				Map<String, Object> hashes = MiniJson.objeto(f.get("hashes"));
				a.sha1 = hashes == null ? null : MiniJson.texto(hashes.get("sha1"));
				if (a.url == null) {
					throw new IOException("O arquivo " + caminho + " não tem um endereço de download permitido.");
				}
				int de = 20 + (70 * (feitos - 1)) / total;
				int ate = 20 + (70 * feitos) / total;
				GerenciadorBiblioteca.baixarVerificado(a, alvo.toFile(), progresso, de, ate);
			}

			// 5. Configs e outros arquivos do próprio pacote
			progresso.atualizar("Copiando configurações do modpack...", 92);
			extrairOverrides(zip, "overrides/", raizModpack);
			extrairOverrides(zip, "client-overrides/", raizModpack);
			progresso.atualizar("Pronto.", 100);
			return nome;
		} catch (Exception erro) {
			if (modpackDir != null) {
				apagar(modpackDir);
			}
			throw erro;
		}
	}

	private static void conferirCompatibilidade(Map<String, Object> indice, GerenciadorBiblioteca.Destino destino) {
		Map<String, Object> deps = MiniJson.objeto(indice.get("dependencies"));
		if (deps == null) {
			return;
		}
		String mc = MiniJson.texto(deps.get("minecraft"));
		String loader = loaderDoPacote(deps);
		if (loader != null && !loader.equals(destino.loader)) {
			throw new IllegalStateException("Esse modpack é para " + loader + " e a versão escolhida é "
					+ destino.loader + ". Baixe a versão certa na aba Jogar e escolha ela aqui.");
		}
		if (mc != null && destino.versaoMc != null && !mc.equals(destino.versaoMc)) {
			throw new IllegalStateException("Esse modpack é para o Minecraft " + mc + " e a versão escolhida é "
					+ destino.versaoMc + ". Baixe a versão certa na aba Jogar e escolha ela aqui.");
		}
	}

	/** mods/x.jar vira x.jar na raiz do modpack (é onde o launcher procura); o resto vai para overrides/. */
	private static String destinoDentroDoModpack(String caminhoDoPacote) throws IOException {
		if (caminhoDoPacote == null) {
			throw new IOException("Um arquivo do modpack veio sem caminho.");
		}
		String c = caminhoDoPacote.replace('\\', '/');
		if (c.startsWith("mods/") && c.indexOf('/', 5) < 0 && c.toLowerCase(Locale.ROOT).endsWith(".jar")) {
			return c.substring(5);
		}
		return "overrides/" + c;
	}

	/** Resolve o caminho dentro da pasta do modpack e recusa qualquer coisa que escape dela. */
	private static Path caminhoSeguro(Path raiz, String relativo) throws IOException {
		if (relativo.isEmpty() || relativo.startsWith("/") || relativo.contains(":")) {
			throw new IOException("Caminho inválido no modpack: " + relativo);
		}
		for (String parte : relativo.split("/")) {
			if (parte.equals("..") || parte.isEmpty()) {
				throw new IOException("Caminho inválido no modpack: " + relativo);
			}
		}
		Path alvo = raiz.resolve(relativo).normalize();
		if (!alvo.startsWith(raiz)) {
			throw new IOException("Caminho fora da pasta do modpack: " + relativo);
		}
		return alvo;
	}

	private static void extrairOverrides(ZipFile zip, String prefixo, Path raizModpack) throws IOException {
		long total = 0;
		Enumeration<? extends ZipEntry> entradas = zip.entries();
		while (entradas.hasMoreElements()) {
			ZipEntry e = entradas.nextElement();
			String nome = e.getName().replace('\\', '/');
			if (e.isDirectory() || !nome.startsWith(prefixo) || nome.length() == prefixo.length()) {
				continue;
			}
			Path alvo = caminhoSeguro(raizModpack, "overrides/" + nome.substring(prefixo.length()));
			Files.createDirectories(alvo.getParent());
			try (InputStream in = zip.getInputStream(e)) {
				byte[] bloco = new byte[65536];
				try (java.io.OutputStream out = Files.newOutputStream(alvo)) {
					int lidos;
					while ((lidos = in.read(bloco)) != -1) {
						total += lidos;
						if (total > LIMITE_DESCOMPACTADO) {
							throw new IOException("O modpack descompactado é grande demais; parei por segurança.");
						}
						out.write(bloco, 0, lidos);
					}
				}
			}
		}
	}

	private static void apagar(File alvo) {
		File[] filhos = alvo.listFiles();
		if (filhos != null) {
			for (File f : filhos) {
				apagar(f);
			}
		}
		alvo.delete();
	}
}
