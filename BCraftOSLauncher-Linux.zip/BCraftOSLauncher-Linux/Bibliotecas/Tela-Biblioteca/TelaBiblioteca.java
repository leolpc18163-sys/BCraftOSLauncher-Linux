package BCraftOSproject1.BCraftOS1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

/**
 * Aba "Biblioteca": procura mods, plugins e modpacks no Modrinth, guarda tudo numa biblioteca local
 * e instala no cliente (num modpack) ou num servidor do launcher.
 *
 * Quatro categorias: Mods, Plugins, Modpacks e Minha biblioteca (o que já foi baixado).
 */
public class TelaBiblioteca {

	private static final Color COR_FUNDO = new Color(18, 18, 18);
	private static final Color COR_PAINEL = new Color(26, 26, 26);
	private static final Color COR_DESTAQUE = new Color(170, 90, 240);
	private static final Color COR_BORDA = new Color(70, 70, 70);
	private static final Color COR_TEXTO = new Color(230, 230, 230);
	private static final Color COR_TEXTO_FRACO = new Color(150, 150, 150);

	private static final int LARGURA = EscalaTela.px(640);

	private static final String CAT_MODS = "Mods";
	private static final String CAT_PLUGINS = "Plugins";
	private static final String CAT_MODPACKS = "Modpacks";
	private static final String CAT_BIBLIOTECA = "Minha biblioteca";
	private static final String[] CATEGORIAS = { CAT_MODS, CAT_PLUGINS, CAT_MODPACKS, CAT_BIBLIOTECA };

	private final JFrame janela;
	private final JPanel painel;
	private final JComponent componente;

	private final JButton[] botoesCategoria = new JButton[CATEGORIAS.length];
	private JComboBox<GerenciadorBiblioteca.Destino> seletorDestino;
	private JComboBox<String> seletorModpack;
	private JButton botaoNovoModpack;
	private JLabel rotuloModpack;
	private JPanel linhaModpack;
	private JTextField campoBusca;
	private JButton botaoBuscar;
	private DefaultListModel<Object> modeloLista;
	private JList<Object> lista;
	private JLabel statusLabel;
	private JProgressBar barra;
	private JButton botaoAcao;
	private JButton botaoExcluir;

	private String categoria = CAT_MODS;
	private boolean ocupado;
	private boolean primeiraVez = true;
	private boolean atualizandoDestinos;
	private long pedidoAtual;

	public TelaBiblioteca(JFrame janela) {
		this.janela = janela;
		this.painel = montarPainel();
		this.componente = envolverEmRolagem(painel);
	}

	public JComponent getPainel() {
		return componente;
	}

	/** Chamado toda vez que a pessoa abre a aba. */
	public void aoMostrar() {
		if (primeiraVez) {
			primeiraVez = false;
			trocarCategoria(CAT_MODS);
		} else {
			recarregarDestinos();
		}
	}

	private static JComponent envolverEmRolagem(JPanel conteudo) {
		JScrollPane rolagem = new JScrollPane(conteudo, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER) {
			private static final long serialVersionUID = 1L;

			@Override
			public Dimension getPreferredSize() {
				Dimension d = super.getPreferredSize();
				d.height = Math.min(d.height, Math.max(420, EscalaTela.areaUtil().height - EscalaTela.px(200)));
				return d;
			}
		};
		rolagem.setBorder(BorderFactory.createEmptyBorder());
		rolagem.setOpaque(false);
		rolagem.getViewport().setOpaque(false);
		rolagem.getVerticalScrollBar().setUnitIncrement(16);
		return rolagem;
	}

	// ------------------------------------------------------------------
	// Layout
	// ------------------------------------------------------------------

	private JPanel montarPainel() {
		JPanel p = new JPanel(new GridBagLayout());
		p.setBackground(COR_PAINEL);
		p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(COR_BORDA, 1),
				BorderFactory.createEmptyBorder(EscalaTela.px(22), EscalaTela.px(26), EscalaTela.px(22),
						EscalaTela.px(26))));

		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.weightx = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.anchor = GridBagConstraints.WEST;
		int linha = 0;

		JLabel titulo = new JLabel("Biblioteca");
		titulo.setFont(EscalaTela.fonte(java.awt.Font.BOLD, 24));
		titulo.setForeground(COR_DESTAQUE);
		linha = adicionar(p, c, linha, titulo, 4);

		JLabel subtitulo = new JLabel("Mods, plugins e modpacks do Modrinth, guardados no seu PC.");
		subtitulo.setFont(EscalaTela.fonte(java.awt.Font.PLAIN, 12));
		subtitulo.setForeground(COR_TEXTO_FRACO);
		linha = adicionar(p, c, linha, subtitulo, 16);

		// Categorias
		JPanel categorias = new JPanel(new GridLayout(1, CATEGORIAS.length, EscalaTela.px(6), 0));
		categorias.setOpaque(false);
		for (int i = 0; i < CATEGORIAS.length; i++) {
			final String nome = CATEGORIAS[i];
			JButton b = new JButton(nome);
			b.addActionListener(e -> trocarCategoria(nome));
			botoesCategoria[i] = b;
			categorias.add(b);
		}
		linha = adicionar(p, c, linha, categorias, 16);

		// Destino
		linha = adicionar(p, c, linha, rotulo("Instalar em:"), 6);
		seletorDestino = new JComboBox<>();
		estilizarSeletor(seletorDestino);
		seletorDestino.addActionListener(e -> aoMudarDestino());
		linha = adicionar(p, c, linha, seletorDestino, 8);

		rotuloModpack = rotulo("Modpack:");
		seletorModpack = new JComboBox<>();
		estilizarSeletor(seletorModpack);
		botaoNovoModpack = new JButton("Novo modpack");
		estilizarBotao(botaoNovoModpack, false, 40);
		botaoNovoModpack.addActionListener(e -> criarNovoModpack());
		linhaModpack = new JPanel(new BorderLayout(EscalaTela.px(8), 0));
		linhaModpack.setOpaque(false);
		linhaModpack.add(seletorModpack, BorderLayout.CENTER);
		linhaModpack.add(botaoNovoModpack, BorderLayout.EAST);
		JPanel blocoModpack = new JPanel(new BorderLayout(0, EscalaTela.px(6)));
		blocoModpack.setOpaque(false);
		blocoModpack.add(rotuloModpack, BorderLayout.NORTH);
		blocoModpack.add(linhaModpack, BorderLayout.CENTER);
		blocoModpack.setName("blocoModpack");
		linha = adicionar(p, c, linha, blocoModpack, 12);

		// Busca
		campoBusca = new JTextField();
		campoBusca.setFont(EscalaTela.fonte(java.awt.Font.PLAIN, 14));
		campoBusca.setBackground(COR_FUNDO);
		campoBusca.setForeground(Color.WHITE);
		campoBusca.setCaretColor(Color.WHITE);
		campoBusca.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(COR_BORDA, 1),
				BorderFactory.createEmptyBorder(0, EscalaTela.px(8), 0, EscalaTela.px(8))));
		campoBusca.setPreferredSize(new Dimension(EscalaTela.px(200), EscalaTela.px(40)));
		campoBusca.addActionListener(e -> executarBusca());
		botaoBuscar = new JButton("Buscar");
		estilizarBotao(botaoBuscar, true, 40);
		botaoBuscar.addActionListener(e -> executarBusca());
		JPanel linhaBusca = new JPanel(new BorderLayout(EscalaTela.px(8), 0));
		linhaBusca.setOpaque(false);
		linhaBusca.add(campoBusca, BorderLayout.CENTER);
		linhaBusca.add(botaoBuscar, BorderLayout.EAST);
		linha = adicionar(p, c, linha, linhaBusca, 10);

		// Lista
		modeloLista = new DefaultListModel<>();
		lista = new JList<>(modeloLista);
		lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		lista.setBackground(COR_FUNDO);
		lista.setForeground(COR_TEXTO);
		lista.setSelectionBackground(new Color(70, 40, 100));
		lista.setSelectionForeground(Color.WHITE);
		lista.setFixedCellHeight(EscalaTela.px(54));
		lista.setCellRenderer(new RenderizadorLista());
		lista.addListSelectionListener(e -> {
			if (!e.getValueIsAdjusting()) {
				aoSelecionarItem();
			}
		});
		JScrollPane rolagemLista = new JScrollPane(lista);
		rolagemLista.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
		rolagemLista.getViewport().setBackground(COR_FUNDO);
		rolagemLista.getVerticalScrollBar().setUnitIncrement(16);
		rolagemLista.setPreferredSize(new Dimension(LARGURA, EscalaTela.px(270)));
		GridBagConstraints cl = (GridBagConstraints) c.clone();
		cl.gridy = linha++;
		cl.insets = new Insets(0, 0, EscalaTela.px(8), 0);
		cl.weighty = 1;
		cl.fill = GridBagConstraints.BOTH;
		p.add(rolagemLista, cl);

		// Andamento
		barra = new JProgressBar(0, 100);
		barra.setPreferredSize(new Dimension(LARGURA, EscalaTela.px(6)));
		barra.setBackground(COR_FUNDO);
		barra.setForeground(COR_DESTAQUE);
		barra.setBorderPainted(false);
		barra.setVisible(false);
		linha = adicionar(p, c, linha, barra, 6);

		statusLabel = new JLabel(" ");
		statusLabel.setFont(EscalaTela.fonte(java.awt.Font.PLAIN, 11));
		statusLabel.setForeground(COR_TEXTO_FRACO);
		linha = adicionar(p, c, linha, statusLabel, 10);

		botaoAcao = new JButton("Baixar e instalar");
		estilizarBotao(botaoAcao, true, 44);
		botaoAcao.addActionListener(e -> executarAcao());
		botaoExcluir = new JButton("Excluir da biblioteca");
		estilizarBotao(botaoExcluir, false, 44);
		botaoExcluir.addActionListener(e -> excluirSelecionado());
		JPanel linhaBotoes = new JPanel(new GridBagLayout());
		linhaBotoes.setOpaque(false);
		GridBagConstraints cb = new GridBagConstraints();
		cb.gridy = 0;
		cb.fill = GridBagConstraints.HORIZONTAL;
		cb.weightx = 1;
		cb.gridx = 0;
		linhaBotoes.add(botaoAcao, cb);
		cb.gridx = 1;
		cb.weightx = 0;
		cb.insets = new Insets(0, EscalaTela.px(8), 0, 0);
		linhaBotoes.add(botaoExcluir, cb);
		adicionar(p, c, linha, linhaBotoes, 0);

		return p;
	}

	private int adicionar(JPanel p, GridBagConstraints c, int linha, Component comp, int espacoAbaixo) {
		c.gridy = linha;
		c.insets = new Insets(0, 0, EscalaTela.px(espacoAbaixo), 0);
		c.weighty = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		p.add(comp, c);
		return linha + 1;
	}

	private JLabel rotulo(String texto) {
		JLabel l = new JLabel(texto);
		l.setFont(EscalaTela.fonte(java.awt.Font.BOLD, 12));
		l.setForeground(Color.WHITE);
		return l;
	}

	private void estilizarSeletor(JComboBox<?> s) {
		s.setFont(EscalaTela.fonte(java.awt.Font.PLAIN, 14));
		s.setBackground(COR_FUNDO);
		s.setForeground(Color.WHITE);
		s.setPreferredSize(new Dimension(EscalaTela.px(200), EscalaTela.px(40)));
		s.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
	}

	private void estilizarBotao(JButton b, boolean principal, int altura) {
		b.setFont(EscalaTela.fonte(java.awt.Font.BOLD, 13));
		b.setFocusPainted(false);
		b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		b.setPreferredSize(new Dimension(EscalaTela.px(150), EscalaTela.px(altura)));
		if (principal) {
			b.setBackground(COR_DESTAQUE);
			b.setForeground(Color.BLACK);
		} else {
			b.setBackground(COR_FUNDO);
			b.setForeground(COR_TEXTO);
			b.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
		}
	}

	private void estilizarCategorias() {
		for (int i = 0; i < CATEGORIAS.length; i++) {
			JButton b = botoesCategoria[i];
			boolean ativa = CATEGORIAS[i].equals(categoria);
			b.setFont(EscalaTela.fonte(java.awt.Font.BOLD, 12));
			b.setFocusPainted(false);
			b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			b.setPreferredSize(new Dimension(EscalaTela.px(100), EscalaTela.px(36)));
			if (ativa) {
				b.setBackground(COR_DESTAQUE);
				b.setForeground(Color.BLACK);
				b.setBorder(BorderFactory.createLineBorder(COR_DESTAQUE, 1));
			} else {
				b.setBackground(COR_FUNDO);
				b.setForeground(COR_TEXTO);
				b.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
			}
		}
	}

	// ------------------------------------------------------------------
	// Categorias e destinos
	// ------------------------------------------------------------------

	private boolean ehBiblioteca() {
		return CAT_BIBLIOTECA.equals(categoria);
	}

	private void trocarCategoria(String nova) {
		categoria = nova;
		estilizarCategorias();
		modeloLista.clear();
		campoBusca.setText("");
		boolean biblioteca = ehBiblioteca();
		campoBusca.setVisible(!biblioteca);
		botaoBuscar.setVisible(!biblioteca);
		((JComponent) campoBusca.getParent()).setVisible(!biblioteca);
		botaoExcluir.setVisible(biblioteca);
		botaoAcao.setText(biblioteca ? "Instalar no destino" : CAT_MODPACKS.equals(categoria) ? "Baixar e instalar modpack"
				: "Baixar e instalar");
		campoBusca.setToolTipText(null);
		recarregarDestinos();
		if (biblioteca) {
			carregarBiblioteca();
		} else if (seletorDestino.getItemCount() > 0) {
			executarBusca();
		}
		painel.revalidate();
		painel.repaint();
	}

	/** O destino depende da categoria; na biblioteca, depende do item escolhido (mod ou plugin). */
	private List<GerenciadorBiblioteca.Destino> destinosDaCategoria() {
		List<GerenciadorBiblioteca.Destino> destinos = new ArrayList<>();
		switch (categoria) {
			case CAT_MODS:
				destinos.addAll(GerenciadorBiblioteca.destinosDeCliente());
				destinos.addAll(GerenciadorBiblioteca.destinosDeServidor(false));
				break;
			case CAT_PLUGINS:
				destinos.addAll(GerenciadorBiblioteca.destinosDeServidor(true));
				break;
			case CAT_MODPACKS:
				destinos.addAll(GerenciadorBiblioteca.destinosDeCliente());
				break;
			default: {
				Object sel = lista == null ? null : lista.getSelectedValue();
				boolean plugin = sel instanceof GerenciadorBiblioteca.ItemBiblioteca
						&& GerenciadorBiblioteca.PASTA_PLUGINS.equals(((GerenciadorBiblioteca.ItemBiblioteca) sel).tipo);
				if (plugin) {
					destinos.addAll(GerenciadorBiblioteca.destinosDeServidor(true));
				} else {
					destinos.addAll(GerenciadorBiblioteca.destinosDeCliente());
					destinos.addAll(GerenciadorBiblioteca.destinosDeServidor(false));
				}
			}
		}
		return destinos;
	}

	private void recarregarDestinos() {
		GerenciadorBiblioteca.Destino anterior = (GerenciadorBiblioteca.Destino) seletorDestino.getSelectedItem();
		atualizandoDestinos = true;
		DefaultComboBoxModel<GerenciadorBiblioteca.Destino> modelo = new DefaultComboBoxModel<>();
		for (GerenciadorBiblioteca.Destino d : destinosDaCategoria()) {
			modelo.addElement(d);
		}
		seletorDestino.setModel(modelo);
		if (anterior != null) {
			for (int i = 0; i < modelo.getSize(); i++) {
				if (modelo.getElementAt(i).rotulo.equals(anterior.rotulo)) {
					seletorDestino.setSelectedIndex(i);
					break;
				}
			}
		}
		atualizandoDestinos = false;
		atualizarModpacks();
		atualizarBotoes();
		if (modelo.getSize() == 0) {
			String dica = CAT_PLUGINS.equals(categoria)
					? "Nenhum servidor com plugins ainda. Crie um Paper, Purpur ou Spigot na aba Servidor."
					: CAT_MODPACKS.equals(categoria)
							? "Nenhuma versão baixada ainda. Baixe uma na aba Jogar."
							: "Nenhum destino ainda: baixe uma versão na aba Jogar ou crie um servidor na aba Servidor.";
			statusLabel.setText(dica);
		}
	}

	private void aoMudarDestino() {
		if (atualizandoDestinos) {
			return;
		}
		atualizarModpacks();
		atualizarBotoes();
		if (!ehBiblioteca() && seletorDestino.getItemCount() > 0) {
			executarBusca(); // os filtros (loader e versão) mudaram
		}
	}

	/** O seletor de modpack só aparece quando o destino é uma versão do cliente e a categoria é Mods/Biblioteca. */
	private void atualizarModpacks() {
		GerenciadorBiblioteca.Destino d = (GerenciadorBiblioteca.Destino) seletorDestino.getSelectedItem();
		boolean mostrar = d != null && !d.servidor && !CAT_MODPACKS.equals(categoria) && !CAT_PLUGINS.equals(categoria);
		linhaModpack.getParent().setVisible(mostrar);
		if (mostrar) {
			DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
			for (String nome : GerenciadorBiblioteca.listarModpacks(d)) {
				modelo.addElement(nome);
			}
			seletorModpack.setModel(modelo);
		}
		painel.revalidate();
	}

	private void criarNovoModpack() {
		GerenciadorBiblioteca.Destino d = (GerenciadorBiblioteca.Destino) seletorDestino.getSelectedItem();
		if (d == null || d.servidor) {
			return;
		}
		String nome = JOptionPane.showInputDialog(janela, "Nome do novo modpack:", "Novo modpack",
				JOptionPane.PLAIN_MESSAGE);
		if (nome == null) {
			return;
		}
		try {
			String criado = GerenciadorBiblioteca.criarModpack(d, nome);
			atualizarModpacks();
			seletorModpack.setSelectedItem(criado);
		} catch (IllegalStateException erro) {
			JOptionPane.showMessageDialog(janela, erro.getMessage(), "Modpack", JOptionPane.WARNING_MESSAGE);
		}
	}

	private void atualizarBotoes() {
		boolean temDestino = seletorDestino.getItemCount() > 0;
		boolean temItem = lista.getSelectedValue() != null;
		botaoAcao.setEnabled(!ocupado && temDestino && temItem);
		botaoExcluir.setEnabled(!ocupado && temItem);
		botaoBuscar.setEnabled(!ocupado && temDestino);
		botaoNovoModpack.setEnabled(!ocupado);
		seletorDestino.setEnabled(!ocupado);
		seletorModpack.setEnabled(!ocupado);
		for (JButton b : botoesCategoria) {
			b.setEnabled(!ocupado);
		}
	}

	private void aoSelecionarItem() {
		if (ehBiblioteca()) {
			recarregarDestinos(); // mod e plugin vão para destinos diferentes
		}
		atualizarBotoes();
	}

	// ------------------------------------------------------------------
	// Busca
	// ------------------------------------------------------------------

	private String tipoProjeto() {
		switch (categoria) {
			case CAT_PLUGINS:
				return CatalogoModrinth.PLUGIN;
			case CAT_MODPACKS:
				return CatalogoModrinth.MODPACK;
			default:
				return CatalogoModrinth.MOD;
		}
	}

	private void executarBusca() {
		GerenciadorBiblioteca.Destino destino = (GerenciadorBiblioteca.Destino) seletorDestino.getSelectedItem();
		if (ehBiblioteca() || destino == null || ocupado) {
			return;
		}
		final long meuPedido = ++pedidoAtual;
		final String consulta = campoBusca.getText();
		final String tipo = tipoProjeto();
		modeloLista.clear();
		statusLabel.setText("Procurando no Modrinth...");
		new SwingWorker<List<CatalogoModrinth.Projeto>, Void>() {
			@Override
			protected List<CatalogoModrinth.Projeto> doInBackground() throws Exception {
				return CatalogoModrinth.buscar(consulta, tipo, destino.loadersBusca, destino.versaoMc, 30);
			}

			@Override
			protected void done() {
				if (meuPedido != pedidoAtual) {
					return; // chegou uma busca mais nova
				}
				try {
					List<CatalogoModrinth.Projeto> projetos = get();
					modeloLista.clear();
					for (CatalogoModrinth.Projeto p : projetos) {
						modeloLista.addElement(p);
					}
					String filtro = String.join("/", destino.loadersBusca)
							+ (destino.versaoMc == null ? "" : " " + destino.versaoMc);
					statusLabel.setText(projetos.isEmpty() ? "Nada encontrado para " + filtro + "."
							: projetos.size() + " resultado(s) para " + filtro
									+ (consulta.isBlank() ? " (os mais baixados)." : "."));
				} catch (Exception erro) {
					Throwable causa = erro.getCause() != null ? erro.getCause() : erro;
					statusLabel.setText("Não consegui falar com o Modrinth: " + causa.getMessage()
							+ ". Confira a internet.");
				}
				atualizarBotoes();
			}
		}.execute();
	}

	private void carregarBiblioteca() {
		modeloLista.clear();
		List<GerenciadorBiblioteca.ItemBiblioteca> itens = GerenciadorBiblioteca.listarBiblioteca();
		for (GerenciadorBiblioteca.ItemBiblioteca i : itens) {
			modeloLista.addElement(i);
		}
		statusLabel.setText(itens.isEmpty()
				? "A biblioteca está vazia. Baixe mods ou plugins nas outras categorias e eles aparecem aqui."
				: itens.size() + " arquivo(s) na biblioteca. Escolha um e instale no destino, sem baixar de novo.");
		atualizarBotoes();
	}

	// ------------------------------------------------------------------
	// Ações
	// ------------------------------------------------------------------

	private void definirOcupado(boolean valor) {
		ocupado = valor;
		barra.setVisible(valor);
		if (valor) {
			barra.setValue(0);
		}
		atualizarBotoes();
	}

	private GerenciadorDownloads.Progresso progressoNaTela() {
		return (etapa, pct) -> SwingUtilities.invokeLater(() -> {
			statusLabel.setText(etapa);
			barra.setValue(Math.max(0, Math.min(100, pct)));
		});
	}

	private void executarAcao() {
		GerenciadorBiblioteca.Destino destino = (GerenciadorBiblioteca.Destino) seletorDestino.getSelectedItem();
		Object escolhido = lista.getSelectedValue();
		if (destino == null || escolhido == null || ocupado) {
			return;
		}
		final String nomeModpack = (String) seletorModpack.getSelectedItem();
		boolean precisaModpack = !destino.servidor && !CAT_MODPACKS.equals(categoria);
		if (precisaModpack && (nomeModpack == null || nomeModpack.isEmpty())) {
			JOptionPane.showMessageDialog(janela, "Escolha (ou crie) o modpack que vai receber o arquivo.",
					"Modpack", JOptionPane.INFORMATION_MESSAGE);
			return;
		}

		definirOcupado(true);
		final GerenciadorDownloads.Progresso progresso = progressoNaTela();
		new SwingWorker<String, Void>() {
			@Override
			protected String doInBackground() throws Exception {
				if (escolhido instanceof GerenciadorBiblioteca.ItemBiblioteca) {
					String nome = GerenciadorBiblioteca.instalarDaBiblioteca(
							(GerenciadorBiblioteca.ItemBiblioteca) escolhido, destino, nomeModpack);
					return "Instalado: " + nome;
				}
				CatalogoModrinth.Projeto projeto = (CatalogoModrinth.Projeto) escolhido;
				progresso.atualizar("Escolhendo a melhor versão de " + projeto.titulo + "...", 1);
				CatalogoModrinth.Versao versao = CatalogoModrinth.melhorVersao(projeto.id, destino.loadersBusca,
						destino.versaoMc);
				if (versao == null) {
					throw new IllegalStateException(projeto.titulo + " não tem versão para "
							+ String.join("/", destino.loadersBusca)
							+ (destino.versaoMc == null ? "" : " " + destino.versaoMc) + ".");
				}
				if (CAT_MODPACKS.equals(categoria)) {
					String criado = InstaladorMrpack.instalar(versao, projeto.slug, destino, progresso);
					return "Modpack \"" + criado + "\" instalado. Escolha ele na aba Jogar.";
				}
				String pasta = CAT_PLUGINS.equals(categoria) ? GerenciadorBiblioteca.PASTA_PLUGINS
						: GerenciadorBiblioteca.PASTA_MODS;
				GerenciadorBiblioteca.Resultado r = GerenciadorBiblioteca.instalar(versao, pasta, destino, nomeModpack,
						progresso);
				StringBuilder msg = new StringBuilder("Instalado: " + String.join(", ", r.instalados));
				if (!r.avisos.isEmpty()) {
					msg.append("\nAvisos: ").append(String.join("; ", r.avisos));
				}
				return msg.toString();
			}

			@Override
			protected void done() {
				definirOcupado(false);
				try {
					String mensagem = get();
					statusLabel.setText(mensagem.replace('\n', ' '));
					if (mensagem.contains("\n")) {
						JOptionPane.showMessageDialog(janela, mensagem, "Biblioteca", JOptionPane.INFORMATION_MESSAGE);
					}
					if (ehBiblioteca()) {
						carregarBiblioteca();
					}
				} catch (Exception erro) {
					Throwable causa = erro.getCause() != null ? erro.getCause() : erro;
					statusLabel.setText("Não deu certo: " + causa.getMessage());
					JOptionPane.showMessageDialog(janela, causa.getMessage(), "Biblioteca", JOptionPane.WARNING_MESSAGE);
				}
			}
		}.execute();
	}

	private void excluirSelecionado() {
		Object escolhido = lista.getSelectedValue();
		if (!(escolhido instanceof GerenciadorBiblioteca.ItemBiblioteca) || ocupado) {
			return;
		}
		GerenciadorBiblioteca.ItemBiblioteca item = (GerenciadorBiblioteca.ItemBiblioteca) escolhido;
		int r = JOptionPane.showConfirmDialog(janela,
				"Apagar " + item.arquivo.getName() + " da biblioteca?\n(Cópias já instaladas em modpacks e servidores não são afetadas.)",
				"Excluir da biblioteca", JOptionPane.YES_NO_OPTION);
		if (r != JOptionPane.YES_OPTION) {
			return;
		}
		try {
			GerenciadorBiblioteca.excluirDaBiblioteca(item);
		} catch (java.io.IOException erro) {
			JOptionPane.showMessageDialog(janela, erro.getMessage(), "Biblioteca", JOptionPane.WARNING_MESSAGE);
		}
		carregarBiblioteca();
	}

	// ------------------------------------------------------------------
	// Linha da lista
	// ------------------------------------------------------------------

	private static String escaparHtml(String t) {
		return t == null ? "" : t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
	}

	private static String resumo(String texto, int max) {
		if (texto == null) {
			return "";
		}
		return texto.length() > max ? texto.substring(0, max - 1) + "…" : texto;
	}

	private static String baixados(long n) {
		if (n >= 1_000_000) {
			return String.format(java.util.Locale.ROOT, "%.1f mi", n / 1_000_000.0);
		}
		if (n >= 1_000) {
			return (n / 1_000) + " mil";
		}
		return String.valueOf(n);
	}

	private static class RenderizadorLista extends javax.swing.DefaultListCellRenderer {
		private static final long serialVersionUID = 1L;

		@Override
		public Component getListCellRendererComponent(JList<?> list, Object valor, int indice, boolean selecionado,
				boolean foco) {
			JLabel l = (JLabel) super.getListCellRendererComponent(list, "", indice, selecionado, foco);
			String html;
			if (valor instanceof CatalogoModrinth.Projeto) {
				CatalogoModrinth.Projeto p = (CatalogoModrinth.Projeto) valor;
				html = "<b>" + escaparHtml(p.titulo) + "</b> <font color='#969696'>por " + escaparHtml(p.autor) + " · "
						+ baixados(p.downloads) + " downloads</font><br><font color='#b4b4b4'>"
						+ escaparHtml(resumo(p.descricao, 110)) + "</font>";
			} else if (valor instanceof GerenciadorBiblioteca.ItemBiblioteca) {
				GerenciadorBiblioteca.ItemBiblioteca i = (GerenciadorBiblioteca.ItemBiblioteca) valor;
				html = "<b>" + escaparHtml(i.arquivo.getName()) + "</b><br><font color='#969696'>"
						+ (GerenciadorBiblioteca.PASTA_PLUGINS.equals(i.tipo) ? "plugin" : "mod") + " · " + escaparHtml(i.loader)
						+ " · Minecraft " + escaparHtml(i.mc) + "</font>";
			} else {
				html = escaparHtml(String.valueOf(valor));
			}
			l.setText("<html><body style='width:" + (LARGURA - EscalaTela.px(60)) + "px'>" + html + "</body></html>");
			l.setBorder(BorderFactory.createEmptyBorder(EscalaTela.px(4), EscalaTela.px(8), EscalaTela.px(4),
					EscalaTela.px(8)));
			l.setFont(EscalaTela.fonte(java.awt.Font.PLAIN, 12));
			return l;
		}
	}
}
