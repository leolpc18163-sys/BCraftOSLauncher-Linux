package BCraftOSproject1.BCraftOS1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Conversa com o Modrinth (modrinth.com), a maior biblioteca aberta de mods, plugins e modpacks.
 * É grátis, não precisa de chave e tem API pública. Aqui só ficam as consultas: baixar e instalar
 * é com o GerenciadorBiblioteca.
 *
 * Tipos de projeto usados: "mod", "plugin" e "modpack".
 */
public final class CatalogoModrinth {

	public static final String MOD = "mod";
	public static final String PLUGIN = "plugin";
	public static final String MODPACK = "modpack";

	/** Para testes: aponta o launcher para um servidor local no lugar do Modrinth. */
	public static final String PROPRIEDADE_API = "bcraftos.modrinth";
	private static final String API_PADRAO = "https://api.modrinth.com/v2";
	private static final String USER_AGENT = "BCraftOS-Launcher/1.0 (github.com/leonardo12321323/BCraftOSLauncherMaine)";
	private static final int TIMEOUT_MS = 15000;

	private CatalogoModrinth() {
	}

	/** Um resultado de busca. */
	public static class Projeto {
		public String id;
		public String slug;
		public String titulo;
		public String autor;
		public String descricao;
		public long downloads;
		public String tipo;

		@Override
		public String toString() {
			return titulo;
		}
	}

	public static class Arquivo {
		public String url;
		public String nome;
		public String sha1;
		public long tamanho;
	}

	public static class Dependencia {
		public String projetoId;
		public String versaoId;
		public String tipo;
	}

	/** Uma versão de um projeto, com o arquivo principal para baixar. */
	public static class Versao {
		public String id;
		public String projetoId;
		public String numero;
		public String nome;
		public String tipo; // release, beta ou alpha
		public List<String> loaders = new ArrayList<>();
		public List<String> versoesJogo = new ArrayList<>();
		public Arquivo arquivo;
		public List<Dependencia> dependencias = new ArrayList<>();
	}

	public static String enderecoApi() {
		String propriedade = System.getProperty(PROPRIEDADE_API);
		return propriedade == null || propriedade.isBlank() ? API_PADRAO : propriedade.trim();
	}

	/**
	 * Procura projetos. loaders e versaoMc são filtros: só volta o que funciona nessa combinação.
	 * Com a busca vazia, volta os mais baixados.
	 */
	public static List<Projeto> buscar(String consulta, String tipoProjeto, List<String> loaders, String versaoMc,
			int limite) throws Exception {
		StringBuilder facetas = new StringBuilder("[[\"project_type:").append(tipoProjeto).append("\"]");
		if (versaoMc != null && !versaoMc.isEmpty()) {
			facetas.append(",[\"versions:").append(escaparFaceta(versaoMc)).append("\"]");
		}
		if (loaders != null && !loaders.isEmpty()) {
			facetas.append(",[");
			for (int i = 0; i < loaders.size(); i++) {
				if (i > 0) {
					facetas.append(',');
				}
				facetas.append("\"categories:").append(escaparFaceta(loaders.get(i))).append('"');
			}
			facetas.append(']');
		}
		facetas.append(']');

		boolean vazia = consulta == null || consulta.isBlank();
		String url = enderecoApi() + "/search?limit=" + limite
				+ "&index=" + (vazia ? "downloads" : "relevance")
				+ (vazia ? "" : "&query=" + codificar(consulta.trim()))
				+ "&facets=" + codificar(facetas.toString());

		Map<String, Object> raiz = MiniJson.objeto(MiniJson.ler(baixarTexto(url)));
		List<Projeto> projetos = new ArrayList<>();
		List<Object> hits = raiz == null ? null : MiniJson.lista(raiz.get("hits"));
		if (hits == null) {
			return projetos;
		}
		for (Object item : hits) {
			Map<String, Object> h = MiniJson.objeto(item);
			if (h == null || MiniJson.texto(h.get("project_id")) == null) {
				continue;
			}
			Projeto p = new Projeto();
			p.id = MiniJson.texto(h.get("project_id"));
			p.slug = MiniJson.texto(h.get("slug"));
			p.titulo = MiniJson.texto(h.get("title"));
			p.autor = MiniJson.texto(h.get("author"));
			p.descricao = MiniJson.texto(h.get("description"));
			p.downloads = numero(h.get("downloads"));
			p.tipo = tipoProjeto;
			if (p.titulo == null) {
				p.titulo = p.slug != null ? p.slug : p.id;
			}
			projetos.add(p);
		}
		return projetos;
	}

	/**
	 * A melhor versão de um projeto para essa combinação de loader e jogo: a mais nova entre as
	 * "release"; se não houver nenhuma, a mais nova de qualquer tipo. Null se nada serve.
	 */
	public static Versao melhorVersao(String projetoId, List<String> loaders, String versaoMc) throws Exception {
		StringBuilder url = new StringBuilder(enderecoApi()).append("/project/").append(codificar(projetoId))
				.append("/version?");
		boolean primeiro = true;
		if (loaders != null && !loaders.isEmpty()) {
			url.append("loaders=").append(codificar(jsonDeLista(loaders)));
			primeiro = false;
		}
		if (versaoMc != null && !versaoMc.isEmpty()) {
			url.append(primeiro ? "" : "&").append("game_versions=").append(codificar(jsonDeLista(List.of(versaoMc))));
		}
		List<Object> lista = MiniJson.lista(MiniJson.ler(baixarTexto(url.toString())));
		if (lista == null) {
			return null;
		}
		Versao qualquer = null;
		for (Object item : lista) { // a API devolve da mais nova para a mais antiga
			Versao v = lerVersao(MiniJson.objeto(item));
			if (v == null) {
				continue;
			}
			if ("release".equals(v.tipo)) {
				return v;
			}
			if (qualquer == null) {
				qualquer = v;
			}
		}
		return qualquer;
	}

	public static Versao versaoPorId(String versaoId) throws Exception {
		return lerVersao(MiniJson.objeto(MiniJson.ler(baixarTexto(enderecoApi() + "/version/" + codificar(versaoId)))));
	}

	/** Nome e dados básicos de um projeto (usado para mostrar o nome das dependências). */
	public static String tituloDoProjeto(String projetoId) {
		try {
			Map<String, Object> p = MiniJson.objeto(MiniJson.ler(baixarTexto(enderecoApi() + "/project/" + codificar(projetoId))));
			String titulo = p == null ? null : MiniJson.texto(p.get("title"));
			return titulo != null ? titulo : projetoId;
		} catch (Exception e) {
			return projetoId;
		}
	}

	private static Versao lerVersao(Map<String, Object> o) {
		if (o == null || MiniJson.texto(o.get("id")) == null) {
			return null;
		}
		Versao v = new Versao();
		v.id = MiniJson.texto(o.get("id"));
		v.projetoId = MiniJson.texto(o.get("project_id"));
		v.numero = MiniJson.texto(o.get("version_number"));
		v.nome = MiniJson.texto(o.get("name"));
		v.tipo = MiniJson.texto(o.get("version_type"));
		v.loaders = textos(o.get("loaders"));
		v.versoesJogo = textos(o.get("game_versions"));

		List<Object> arquivos = MiniJson.lista(o.get("files"));
		Arquivo escolhido = null;
		if (arquivos != null) {
			for (Object item : arquivos) {
				Map<String, Object> f = MiniJson.objeto(item);
				if (f == null || MiniJson.texto(f.get("url")) == null || MiniJson.texto(f.get("filename")) == null) {
					continue;
				}
				Arquivo a = new Arquivo();
				a.url = MiniJson.texto(f.get("url"));
				a.nome = MiniJson.texto(f.get("filename"));
				a.tamanho = numero(f.get("size"));
				Map<String, Object> hashes = MiniJson.objeto(f.get("hashes"));
				a.sha1 = hashes == null ? null : MiniJson.texto(hashes.get("sha1"));
				boolean principal = Boolean.TRUE.equals(f.get("primary"));
				if (escolhido == null || principal) {
					escolhido = a;
				}
				if (principal) {
					break;
				}
			}
		}
		v.arquivo = escolhido;

		List<Object> deps = MiniJson.lista(o.get("dependencies"));
		if (deps != null) {
			for (Object item : deps) {
				Map<String, Object> d = MiniJson.objeto(item);
				if (d == null) {
					continue;
				}
				Dependencia dep = new Dependencia();
				dep.projetoId = MiniJson.texto(d.get("project_id"));
				dep.versaoId = MiniJson.texto(d.get("version_id"));
				dep.tipo = MiniJson.texto(d.get("dependency_type"));
				v.dependencias.add(dep);
			}
		}
		return v.arquivo == null ? null : v;
	}

	// ------------------------------------------------------------------
	// Apoio
	// ------------------------------------------------------------------

	private static List<String> textos(Object lista) {
		List<String> saida = new ArrayList<>();
		List<Object> itens = MiniJson.lista(lista);
		if (itens != null) {
			for (Object item : itens) {
				String t = MiniJson.texto(item);
				if (t != null) {
					saida.add(t);
				}
			}
		}
		return saida;
	}

	private static long numero(Object valor) {
		if (valor instanceof Number) {
			return ((Number) valor).longValue();
		}
		try {
			return valor == null ? 0 : Long.parseLong(String.valueOf(valor));
		} catch (NumberFormatException e) {
			return 0;
		}
	}

	/** Dentro de uma faceta só entram letras, números e . _ - (nada que feche aspas ou colchetes). */
	private static String escaparFaceta(String texto) {
		return texto.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9._-]", "");
	}

	private static String jsonDeLista(List<String> itens) {
		StringBuilder sb = new StringBuilder("[");
		for (int i = 0; i < itens.size(); i++) {
			if (i > 0) {
				sb.append(',');
			}
			sb.append('"').append(escaparFaceta(itens.get(i))).append('"');
		}
		return sb.append(']').toString();
	}

	private static String codificar(String texto) {
		return URLEncoder.encode(texto, StandardCharsets.UTF_8);
	}

	/** Endereços de download aceitos: só o CDN do Modrinth e os hospedeiros que o formato .mrpack permite. */
	public static boolean enderecoPermitido(String endereco) {
		try {
			URI uri = URI.create(endereco);
			String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
			if ("https".equalsIgnoreCase(uri.getScheme())) {
				return host.equals("cdn.modrinth.com") || host.equals("github.com")
						|| host.equals("raw.githubusercontent.com") || host.equals("gitlab.com");
			}
			// Só nos testes (propriedade ligada) vale o servidor local.
			String api = System.getProperty(PROPRIEDADE_API);
			return api != null && "http".equalsIgnoreCase(uri.getScheme())
					&& host.equals(URI.create(api).getHost());
		} catch (RuntimeException e) {
			return false;
		}
	}

	static String baixarTexto(String endereco) throws IOException {
		HttpURLConnection conexao = null;
		try {
			conexao = (HttpURLConnection) URI.create(endereco).toURL().openConnection();
			conexao.setConnectTimeout(TIMEOUT_MS);
			conexao.setReadTimeout(TIMEOUT_MS);
			conexao.setRequestProperty("User-Agent", USER_AGENT);
			conexao.setRequestProperty("Accept", "application/json");
			int codigo = conexao.getResponseCode();
			if (codigo != HttpURLConnection.HTTP_OK) {
				throw new IOException("O Modrinth respondeu " + codigo);
			}
			try (InputStream entrada = conexao.getInputStream();
					BufferedReader leitor = new BufferedReader(new InputStreamReader(entrada, StandardCharsets.UTF_8))) {
				StringBuilder texto = new StringBuilder();
				char[] bloco = new char[8192];
				int lidos;
				while ((lidos = leitor.read(bloco)) != -1) {
					texto.append(bloco, 0, lidos);
					if (texto.length() > 20_000_000) {
						throw new IOException("Resposta grande demais");
					}
				}
				return texto.toString();
			}
		} catch (IllegalArgumentException enderecoRuim) {
			throw new IOException("Endereço inválido: " + endereco);
		} finally {
			if (conexao != null) {
				conexao.disconnect();
			}
		}
	}
}
