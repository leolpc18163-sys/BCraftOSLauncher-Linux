#!/usr/bin/env bash
set -euo pipefail

launcher_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
launcher="$launcher_dir/executar.sh"

if [[ ! -f "$launcher" ]]; then
  printf 'Nao encontrei executar.sh em %s\n' "$launcher_dir" >&2
  exit 1
fi

chmod +x "$launcher"

desktop_escape() {
  local value=$1
  value=${value//\\/\\\\}
  value=${value//\"/\\\"}
  value=${value//%/%%}
  printf '%s' "$value"
}

applications_dir="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "$applications_dir"
entry="$applications_dir/bcraftos-launcher.desktop"
escaped_launcher=$(desktop_escape "$launcher")

cat > "$entry" <<EOF
[Desktop Entry]
Type=Application
Name=BCraftOS Launcher
Comment=Open the BCraftOS Launcher
Exec=/bin/bash "$escaped_launcher"
Terminal=true
Categories=Game;
EOF
chmod +x "$entry"

desktop_dir=""
if command -v xdg-user-dir >/dev/null 2>&1; then
  desktop_dir=$(xdg-user-dir DESKTOP 2>/dev/null || true)
fi
if [[ -z "$desktop_dir" ]]; then
  desktop_dir="$HOME/Desktop"
fi
if [[ -d "$desktop_dir" ]]; then
  install -m 755 "$entry" "$desktop_dir/BCraftOS Launcher.desktop"
  printf 'Atalho criado no menu e na Area de Trabalho:\n  %s\n  %s\n' "$entry" "$desktop_dir/BCraftOS Launcher.desktop"
else
  printf 'Atalho criado no menu de aplicativos:\n  %s\n' "$entry"
  printf 'Pasta da Area de Trabalho nao encontrada; o atalho do menu esta pronto.\n'
fi