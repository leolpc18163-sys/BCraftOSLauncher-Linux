#!/usr/bin/env bash
# BCraftOS - instalador automatico de JDK (Linux e Mac).
#
# Uso dentro de outro .sh:
#   source ./JDKs/instalar-jdk.sh
#   garantir_jdk || exit 1
#
# Se o PC ja tem um JDK 17 ou mais novo, usa ele. Se nao tem, baixa o Temurin 21
# (Eclipse Adoptium, gratuito) para a pasta java/jdk-21 desta pasta. Nao precisa
# de root e nao instala nada no sistema.

garantir_jdk() {
  local raiz jdk_local versao maior os arco url_api tmp extraido pasta
  raiz="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
  jdk_local="$raiz/java/jdk-21"

  # 1. JDK do sistema, se for 17+
  if command -v javac >/dev/null 2>&1 && command -v java >/dev/null 2>&1; then
    versao=$(javac -version 2>&1 | awk '{print $2}')
    maior=${versao%%.*}
    maior=${maior%%-*}
    if [[ "$maior" =~ ^[0-9]+$ ]] && [ "$maior" -ge 17 ]; then
      return 0
    fi
  fi

  # 2. JDK que o BCraftOS ja baixou antes
  if [ -f "$jdk_local/.bcraftos-java-ok" ] && [ -x "$jdk_local/bin/javac" ]; then
    export JAVA_HOME="$jdk_local"
    export PATH="$jdk_local/bin:$PATH"
    echo "      Usando o JDK: $JAVA_HOME"
    return 0
  fi

  # 3. Baixa sozinho
  echo
  echo "Nao achei um JDK 17+ neste computador. Vou baixar o Java 21 sozinho"
  echo "(cerca de 200 MB, so na primeira vez, sem precisar de root)."
  echo

  case "$(uname -s)" in
    Linux*) os="linux" ;;
    Darwin*) os="mac" ;;
    *)
      echo "Nao reconheci esse sistema operacional para baixar o Java sozinho."
      echo "Instale um JDK 17+ manualmente: https://adoptium.net/temurin/releases/"
      return 1
      ;;
  esac

  case "$(uname -m)" in
    x86_64 | amd64) arco="x64" ;;
    aarch64 | arm64) arco="aarch64" ;;
    *)
      echo "Essa arquitetura (`uname -m`) nao tem Java 21 para baixar sozinho."
      echo "Instale um JDK 17+ manualmente: https://adoptium.net/temurin/releases/"
      return 1
      ;;
  esac

  url_api="https://api.adoptium.net/v3/binary/latest/21/ga/$os/$arco/jdk/hotspot/normal/eclipse"
  tmp="$raiz/java/.baixando-21"
  rm -rf "$tmp"
  if ! mkdir -p "$tmp" 2>/dev/null; then
    echo "Nao consegui criar a pasta java/ aqui. Mova o launcher para uma pasta onde voce possa gravar."
    return 1
  fi

  echo "[JDK] Baixando o Java 21..."
  if command -v curl >/dev/null 2>&1; then
    curl -fL --progress-bar -o "$tmp/jdk.tar.gz" "$url_api"
  elif command -v wget >/dev/null 2>&1; then
    wget -q --show-progress -O "$tmp/jdk.tar.gz" "$url_api"
  else
    echo "Nao achei o curl nem o wget para baixar o Java."
    echo "Instale um deles, ou instale um JDK 17+ manualmente: https://adoptium.net/temurin/releases/"
    rm -rf "$tmp"
    return 1
  fi
  if [ $? -ne 0 ] || [ ! -s "$tmp/jdk.tar.gz" ]; then
    echo
    echo "Nao consegui baixar o Java. Confira a internet e tente de novo,"
    echo "ou instale um JDK 17+ manualmente: https://adoptium.net/temurin/releases/"
    rm -rf "$tmp"
    return 1
  fi

  echo "[JDK] Extraindo..."
  extraido="$tmp/extraido"
  mkdir -p "$extraido"
  if ! tar -xzf "$tmp/jdk.tar.gz" -C "$extraido"; then
    echo
    echo "Nao consegui extrair o Java. Confira a internet e tente de novo,"
    echo "ou instale um JDK 17+ manualmente: https://adoptium.net/temurin/releases/"
    rm -rf "$tmp"
    return 1
  fi

  pasta=$(find "$extraido" -mindepth 1 -maxdepth 1 -type d | head -n 1)
  if [ -z "$pasta" ]; then
    echo "O arquivo baixado nao tinha uma pasta de JDK dentro."
    rm -rf "$tmp"
    return 1
  fi
  if [ "$os" = "mac" ] && [ -d "$pasta/Contents/Home" ]; then
    pasta="$pasta/Contents/Home"
  fi

  rm -rf "$jdk_local"
  mkdir -p "$(dirname "$jdk_local")"
  mv "$pasta" "$jdk_local"
  if [ ! -x "$jdk_local/bin/javac" ]; then
    echo
    echo "Nao consegui preparar o Java baixado."
    echo "Instale um JDK 17+ manualmente: https://adoptium.net/temurin/releases/"
    rm -rf "$tmp"
    return 1
  fi

  chmod +x "$jdk_local/bin/"* 2>/dev/null
  echo "ok" > "$jdk_local/.bcraftos-java-ok"
  rm -rf "$tmp"
  echo "[JDK] Java 21 instalado em $jdk_local"
  echo

  export JAVA_HOME="$jdk_local"
  export PATH="$jdk_local/bin:$PATH"
  echo "      Usando o JDK: $JAVA_HOME"
  return 0
}
