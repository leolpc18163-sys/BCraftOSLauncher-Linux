#!/usr/bin/env bash
# BCraftOS - abre o launcher no Linux e no Mac.
# Se der erro de permissao, rode uma vez:  chmod +x executar.sh

cd "$(cd "$(dirname "$0")" && pwd)" || exit 1

echo "================================================="
echo "           BCraftOS - Abrindo o launcher"
echo "================================================="
echo

pausar() { read -r -p "Aperte Enter para fechar..." _; }

# Garante o Java: usa o do sistema (17+) ou baixa sozinho para a pasta java/.
if [ -f ./JDKs/instalar-jdk.sh ]; then
  # shellcheck disable=SC1091
  source ./JDKs/instalar-jdk.sh
  if ! garantir_jdk; then
    echo
    echo "Nao consegui deixar o Java pronto. Instale o JDK 17 ou mais novo:"
    echo "  Ubuntu/Debian : sudo apt install openjdk-21-jdk"
    echo "  Fedora        : sudo dnf install java-21-openjdk-devel"
    echo "  Arch          : sudo pacman -S jdk21-openjdk"
    echo "  Mac           : brew install openjdk@21"
    pausar; exit 1
  fi
elif ! command -v javac >/dev/null 2>&1; then
  echo "NAO ACHEI O COMPILADOR JAVA (javac) e o arquivo JDKs/instalar-jdk.sh nao foi encontrado."
  echo "Instale o JDK 17 ou mais novo (sudo apt install openjdk-21-jdk) e tente de novo."
  pausar; exit 1
fi

# [0/3] Atualiza o codigo ANTES de compilar: baixa do GitHub e troca so os arquivos .java que mudaram.
# Nao mexe em versoes/, servidores/, usuarios/, mods nem java/. Sem internet, so avisa e segue.
# Para desligar: crie um arquivo vazio chamado nao-atualizar.txt nesta pasta.
ATUALIZOU=0
if [ -f ./Atualizador/Atualizador/Atualizador.java ]; then
  echo "[0/3] Procurando atualizacoes do codigo..."
  java ./Atualizador/Atualizador/Atualizador.java
  [ $? -eq 10 ] && ATUALIZOU=1
  echo
fi

mkdir -p saida logs

# Usa src/ quando disponivel; senao, compila as categorias organizadas do projeto.
compilar() {
  local ARQUIVOS=()
  if [ -d src ]; then
    mapfile -d '' ARQUIVOS < <(find src -type f -name '*.java' -print0)
  fi
  if [ ${#ARQUIVOS[@]} -eq 0 ]; then
    mapfile -d '' ARQUIVOS < <(find Login Menu Modpacks Servidores Usuarios Verções Bibliotecas JDKs Suporte Atualizador/Gerenciador-de-Downloads \
      -type f -name '*.java' ! -path 'Suporte/Instalador-BCraftOS/*' -print0 2>/dev/null)
  fi
  if [ ${#ARQUIVOS[@]} -eq 0 ]; then
    echo
    echo "NAO ACHEI os arquivos .java do launcher."
    echo "Confira as pastas Login, Menu, Modpacks, Servidores, Usuarios, Verções, Bibliotecas, JDKs e Suporte."
    pausar; exit 1
  fi
  javac -encoding UTF-8 -d saida "${ARQUIVOS[@]}" > logs/compilacao.log 2>&1
}

echo "[1/3] Compilando os arquivos..."
if ! compilar; then
  if [ "$ATUALIZOU" = "1" ]; then
    # A atualizacao trouxe codigo que nao compila: volta para os arquivos de antes e tenta de novo.
    echo
    echo "A atualizacao nao compilou. Voltando para a versao anterior..."
    java ./Atualizador/Atualizador/Atualizador.java --restaurar
    ATUALIZOU=0
    echo "[1/3] Compilando de novo com os arquivos antigos..."
    if compilar; then
      echo "      Compilado. O launcher abre na versao anterior (a atualizacao ficou pausada)."
    else
      cat logs/compilacao.log
      echo
      echo "DEU ERRO AO COMPILAR. As mensagens estao acima e salvas em logs/compilacao.log"
      pausar; exit 1
    fi
  else
    cat logs/compilacao.log
    echo
    echo "DEU ERRO AO COMPILAR. As mensagens estao acima e salvas em logs/compilacao.log"
    echo "Motivo mais comum: arquivo repetido do tipo BCraftOS1(1).java. Apague e tente de novo."
    pausar; exit 1
  fi
fi
echo "      Compilado sem erros."
echo

echo "[2/3] Preparando as pastas..."
mkdir -p versoes usuarios
echo "      Pastas prontas."
echo

echo "[3/3] Abrindo o BCraftOS..."
echo
# O proprio launcher e leve: teto de memoria baixo e coletor simples, para sobrar RAM ao jogo (PC de 2 GB).
java -Xmx512m -XX:+UseSerialGC -Dfile.encoding=UTF-8 -cp saida BCraftOSproject1.BCraftOS1login.BCraftOS1login
CODIGO=$?

echo
if [ $CODIGO -ne 0 ]; then
  echo "O launcher fechou com erro (codigo $CODIGO). As mensagens estao logo acima."
else
  echo "Launcher fechado. Ate a proxima!"
fi
pausar
exit $CODIGO
